import {View, Text, TouchableOpacity } from "react-native"
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useValue } from '../context/ValueContext'
import style from "../style/Header" 
import Logo from "./Logo"
import RecDes from "./RecDes"
export default function Header(){
  const { fmtSaldo, HideValue, showValue } = useValue();
  return(
      <View  style={style.ml}>
            <Logo></Logo>
            <View style={style.parte1}>
            <Text style={style.titulo1}>Olá, Gustavo Donato</Text>
                <Text style={style.saldo}>Saldo em Contas</Text>
                <Text style={style.din}>{fmtSaldo}</Text>
                <TouchableOpacity onPress={HideValue}>
                  <View>
                    <MaterialCommunityIcons
                      name={showValue ? 'eye-off-outline' : 'eye-outline'}
                      size={30}
                      color={"white"}
                      backgroundColor={''}
                      padding={2}
                    />
                  </View>
                </TouchableOpacity>
                <RecDes></RecDes>
            </View>
          </View>
)}