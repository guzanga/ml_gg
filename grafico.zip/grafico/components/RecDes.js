import {View, Text} from "react-native"
import {useContext} from "react"
import { MaterialCommunityIcons } from '@expo/vector-icons';
import style from "../style/RecDes"
import Dados from "../context/DadosContext"
export default function Logo(){
  const {receitas} = useContext(Dados)
  return(
      <View style={style.lado2} >
                  <View style={style.lado3}>
                   <View>
                        < MaterialCommunityIcons style={style.maior} name="arrow-up-circle" />
                  </View>
                  <View>
                      <Text style={style.saldo}>Receitas</Text>
                      <Text style={style.verdi}>R$  {receitas.reduce((soma,item) => soma + parseInt(item.valor), 0)}</Text>
                  </View>
                  </View>
                  <View style={style.lado3} >
                    <View>
                      < MaterialCommunityIcons style={style.menos} name="arrow-down-circle" />
                    </View>
                    <View>
                      <Text style={style.saldo}>Despesas</Text>
                      <Text style={style.vermei}>R$ 0</Text>
                    </View>
                  </View>
                </View>
  )
}