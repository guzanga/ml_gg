import {View} from "react-native"
import { MaterialCommunityIcons } from '@expo/vector-icons';
import style from "../style/icon"

export default function IconUltimosGastos(){
  return(
    <View>
      <MaterialCommunityIcons style={style.icondecor}  name="hammer-wrench" />
    </View>

  )
}