import { Text, View} from "react-native"
import DropDownPicker from 'react-native-dropdown-picker';
import {useState} from "react"
import style from "../style/Origem"
import SwitchSelector from "react-native-switch-selector";
export default function Origem(){
  const options = [
  { label: "Efetivada", value: "1" },
  { label: "Pendente", value: "1" },
];
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState([]);
  const [items, setItems] = useState([
    {label: 'Carteira', value: 'Carteira'},
    {label: 'Corrente', value: 'Corrente'},
    {label: 'Poupança', value: 'Poupança'},
    {label: 'Reserva', value: 'reserva'},
  ]);
  return(
      <>
        <Text style={style.cor}>Origem:</Text>
        <View style={style.tudo}>
        <DropDownPicker  style={style.drop}
        placeholder="Conta:" open={open} value={value} items={items} setOpen={setOpen} setValue={setValue} setItems={setItems} theme="DARK"
      />
      </View>
      <SwitchSelector style={style.swith}
  options={options} initial={0} textColor="purple" buttonColor="purple" selectedColor="white"
  onPress={value => console.log(`Call onPress with value: ${value}`)}
/>
      </>
  )
}