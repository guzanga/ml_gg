import {View, Text, Image} from "react-native"
import style from "../style/Logo"

export default function Logo(){
  return(
      <View  style={style.lado} >
        <Image source={require('../assets/logo.png')}/>
        <Text style={style.logo} >ML</Text>
      </View>
  )
}