import style from "../style/Calc"
import { LinearGradient } from 'expo-linear-gradient';

export default function Linear({children}){
  return(
    <LinearGradient
      colors={['#723FC4', '#000']}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 0.8567 }}
      style={style.bg}>
      {children}
       </LinearGradient>
  )
}

