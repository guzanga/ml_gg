import {View, Text, TextInput, Pressable} from "react-native"
import {useState} from "react"
import style from "../style/NomeCat"
import DropDownPicker from 'react-native-dropdown-picker';
import Origem from "../components/Origem" 
import { useCategoria } from '../context/CategoriaContext';

export default function NomeCat({navigation}){

  const { open, setOpen, value, setValue, items, setItems } = useCategoria();

  return(
      <View style={style.tudo}>
      
        <Text style={style.cor}>Nome:</Text>
        <TextInput style={style.inp}></TextInput>
        <Text style={style.cor}>Categoria:</Text>
        <DropDownPicker style={style.drop} placeholder="Selecione:" open={open}
value={value} items={items} setOpen={setOpen}
        setValue={setValue}
        setItems={setItems}
        theme="DARK"
        multiple={true}
        mode="BADGE"
        badgeDotColors={["#e76f51", "#00b4d8", "#e9c46a", "#e76f51", "#8ac926", "#00b4d8", "#e9c46a"]}
      />

      <View style={style.dois}>
        <Text style={style.cor}>Valor:</Text>
        <TextInput placeholder="   R$:0,00"  placeholderTextColor="white"  style={style.inp2}></TextInput>
      </View>

      <Origem></Origem>
        <View style={style.centro}>
       <Pressable style={style.bb} >
            <Text style={style.tt}>Cadastrar</Text>
        </Pressable>
        </View>
      </View>
   
  )
}  