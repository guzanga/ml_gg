import style from "../style/UltiGast_preco"
import {View, Text} from "react-native"

export default function ValorUltimosGastos({props}){
  return(
    <View>
      <Text style={style.vermei}>R$ 360,00</Text>
    </View>
  )
}