import { View, Dimensions } from 'react-native';
import { PieChart } from 'react-native-svg-charts';
import { Svg } from 'react-native-svg';
import style from "../style/grafic"
const screenWidth = Dimensions.get('window').width;
const data = [
  { key: 1, value: 300, svg: { fill: '#e7dcf2' }, label: 'Carteira' },
  { key: 2, value: 300, svg: { fill: '#b0b6d9' }, label: 'Corrente' },
  { key: 3, value: 300, svg: { fill: '#84c1d9' }, label: 'Poupança' },
  { key: 4, value: 300, svg: { fill: '#eed0f2' }, label: 'Reserva' },
];
export default function Grafico() {
  return (
    <View style={style.tamanho} >
      <Svg width={screenWidth} height={220}>
        <PieChart
          style={{ height: 250 }}
          valueAccessor={({ item }) => item.value}
          data={data}
          spacing={0}
          outerRadius={'85%'}
        />
      </Svg>

    </View>
  );
}
