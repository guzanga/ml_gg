import {View} from "react-native"
import Valor from "./ValorUltimosGastos"
import Icon from "./IconUtimosGastos"
import CatMot from "./CategoriaMotivo"
import style from "../style/Gastos"
export default function Gastos(){
return(
  <>  
      <View style={style.tamanho}>
        <Icon></Icon>
        <CatMot></CatMot>
        <Valor></Valor>
      </View>
      <View style={style.tamanho}>
        <Icon></Icon>
        <CatMot></CatMot>
        <Valor></Valor>
      </View>
      <View style={style.tamanho}>
        <Icon></Icon>
        <CatMot></CatMot>
        <Valor></Valor>
      </View>
  </>
  )
}