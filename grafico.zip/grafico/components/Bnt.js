import {View, Pressable} from "react-native"
import { MaterialCommunityIcons } from '@expo/vector-icons';
import style from "../style/Btn"
export default function Bnt(){
  return(
      <View style={style.fixo}>
        <Pressable style={style.mais}>
          < MaterialCommunityIcons style={style.maisicon} name="plus" />
        </Pressable>
      </View>
  )
}
