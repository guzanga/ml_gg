import {View, Text} from "react-native"
import style from "../style/UltimosGastos"

export default function CategoriaMotivo(){
  return(
      <View>
        <Text style={style.cor}>Ultimos Gastos:</Text>
      </View>
  )
}