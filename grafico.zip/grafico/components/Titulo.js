import {View, Text} from "react-native"
import style from "../style/Titulo"

export default function Titulo(){
  return(
      <View style={style.tamanho}>
        <Text style={style.cor}>Calculadora</Text>
      </View>
  )
}  