import {View, Text} from "react-native"
import style from "../style/CatMot"

export default function CategoriaMotivo(){
  return(
      <View>
        <View>
          <Text style={style.categoria}>Mecanico</Text>
        </View>
        <View>
            <Text style={style.motivo}>Vistoria carro</Text>
        </View>
      </View>
  )
}