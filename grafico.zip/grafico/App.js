import  {useState} from "react"
import Dados from "./context/DadosContext"
import Tabs from "./navegacao/Tabs"
import { ValueProvider } from './context/ValueContext' 
import {CategoriaProvider} from './context/CategoriaContext'

export default function() {
  const [receitas, setReceitas] = useState([])
  const [despesas, setDespesas] = useState([])
  return(
    <Dados.Provider value={{receitas, setReceitas, despesas, setDespesas}}>
      <CategoriaProvider>
      <ValueProvider>
        <Tabs></Tabs>
       </ValueProvider>
       </CategoriaProvider>
      </Dados.Provider>
  )
}
