import {StyleSheet} from "react-native"
import { NavigationContainer } from '@react-navigation/native';
import Home from "../screens/Home"
import Apoio from "../screens/Apoio"
import Despesas from "../screens/Despezas"
import Receitas from "../screens/Receitas"
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Bnt from "../components/Bnt"
import Calculadora from "../screens/Calculadora"

const Tab = createBottomTabNavigator();

export default function() {
  return(
      <NavigationContainer  >
           <Tab.Navigator  
      initialRouteName="Calculadora"
      screenOptions={{
        tabBarActiveTintColor: '#0d125e',
        tabBarInactiveTintColor: 'white',
        headerShown : false,
        tabBarStyle:{
          position: "absolute",
          backgroundColor:"#42286C",
          borderTopColor:"transparent",
          height:55 
        },
      }}
    >
        <Tab.Screen
        name="Home"
        component={Home}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons style={style.icons} name="home-variant" color={color} size={size} />
          ),
        }}
      />
          <Tab.Screen
        name="Despesas"
        component={Despesas}
        options={{
          tabBarLabel: 'Despesas',
          tabBarIcon: ({color, size }) => (
            <MaterialCommunityIcons style={style.icons} name="archive-arrow-down" color={color} size={size} />
          ),
        }}
      />
        <Tab.Screen
        name="Calculadora"
        component={Calculadora}
        options={{
          tabBarLabel: '',
          tabBarIcon: ({ color, size }) => (
            <Bnt></Bnt>
          ),
        }}
      />
      <Tab.Screen
        name="Receitas"
        component={Receitas}
        options={{
          tabBarLabel: 'Receitas',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons style={style.icons} name="hand-coin" color={color} size={size} />
          ),
        }}
      />
          <Tab.Screen
        name="Apoio"
        component={Apoio}
        options={{
          tabBarLabel: 'Apoio',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons style={style.icons} name="handshake" color={color} size={size} />
          ),
        }}
      />
        </Tab.Navigator>
      </NavigationContainer>
  )
}
const style = StyleSheet.create({
icons:{
  fontSize:30,
}
})