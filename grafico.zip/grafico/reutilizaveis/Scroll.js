
import {StyleSheet, ScrollView } from "react-native"


export default function Scroll({children}){
  return(
    <>
      <ScrollView  style={style.scroll}>
        {children}
      </ScrollView >
    </>
  )
}

const style = StyleSheet.create({
    scroll:{
        width: "100%",
        flex: 1
    }
})