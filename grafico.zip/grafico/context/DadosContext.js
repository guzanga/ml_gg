import {createContext} from 'react'

const Dados = createContext();

export default Dados