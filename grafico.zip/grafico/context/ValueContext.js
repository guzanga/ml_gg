import React, { createContext, useContext, useState } from 'react';
const ValueContext = createContext();
export const ValueProvider = ({ children }) => {
  const [showValue, setShowValue] = useState(true);
  const saldo = 3940.57;
  const HideValue = () => {
    setShowValue(!showValue);
  };
  const bolinhas = (str) => {
    return str.replace(/\d/g, '•');
  };
  const fmtNumero = (numero) => {
    const numeroStr = numero.toFixed(2).toString();
    const [pI, pD] = numeroStr.split('.');
    const pIF = pI.length > 3 ?
      pI.replace(/\B(?=(\d{3})+(?!\d))/g, '.') :
      pI;
    return `R$ ${pIF},${pD}`;
  };
  const fmtSaldo = showValue ? fmtNumero(saldo) : bolinhas(fmtNumero(saldo));
  return (
    <ValueContext.Provider value={{ fmtSaldo, HideValue, showValue }}>
      {children}
    </ValueContext.Provider>
  );
};
export const useValue = () => {
  return useContext(ValueContext);
};