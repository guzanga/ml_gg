import React, { createContext, useContext, useState } from 'react';
const CategoriaContext = createContext();

export const CategoriaProvider = ({ children }) => {

  const [open, setOpen] = useState(false);
  const [value, setValue] = useState([]);
  const [items, setItems] = useState([
    {label: 'Spain', value: 'spain'},
    {label: 'Madrid', value: 'madrid'},
    {label: 'Barcelona', value: 'barcelona'},
    {label: 'Italy', value: 'italy'},
    {label: 'Finland', value: 'finland'}
  ]);
  
  return (
    <CategoriaContext.Provider value={{ open, setOpen, value, setValue, items, setItems }}>
      {children}
    </CategoriaContext.Provider>
  );
};
export const useCategoria = () => {
  return useContext(CategoriaContext);
};