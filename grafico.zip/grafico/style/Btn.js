export default{
   mais:{
    backgroundColor:"#BA9FF5",
    height:60,
    width:60,
    alignItems:"center",
    justifyContent:"center",
    borderRadius:60,
    
  },
    maisicon:{
      fontSize:30,
      color:"white",
  },
  fixo:{
    position:"absolute",
    top:-25
  }
}