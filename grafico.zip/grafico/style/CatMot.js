export default{
      motivo:{
        color:"#818DE1",
        fontSize:15
        
    },
      categoria:{
        color:"white",
        fontSize:17
    }
}