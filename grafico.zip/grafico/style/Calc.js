export default{
   bg: {
    flex: 1,
    alignItems: 'center',
    width: '100%',
  },
    container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
}