export default{
          tamanho:{
      height:250,
      borderRadius:25,
      backgroundColor:"#42286C",
      width:"95%",
      margin:20,
      textAlign:"center",
      justifyContent:" center"
    },
}