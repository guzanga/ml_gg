export default{
    cor:{
      color:"white",
      fontSize:35
    },
    tamanho:{
      height:100,
      width:"100%",
      borderRadius:25,
      backgroundColor:"#42286C",
      alignItems:"center",
      justifyContent:"center",
    }
}