export default{
    cor:{
      color:"white",
      marginBottom:10
    }
}