export default{
    inp:{
      borderRadius:7,
      width:300,
      height:40,
      backgroundColor:"#AE55E4",
      opacity:0.55
  },
  cor:{
    color:"white",
    fontSize:15
  },
  drop:{
    backgroundColor:"#AE55E4",
    opacity:0.55,
    borderWidth:0,
    
  },
  tudo:{
      top:20,
      flex: 1,
      paddingHorizontal: 30,
      gap:5
  },
  inp2:{
      borderRadius:7,
      width:160,
      height:50,
      backgroundColor:"#AE55E4",
      opacity:0.55,
      color:"white"
  },
  dois:{
    marginTop:25
  },
  bb:{
    backgroundColor:"purple",
    borderRadius:20,
    width:150,
    justifyContent:"center",
    alignItems:"center",
    height:45,
    textAlign:"center"
    
  },
  tt:{
    color:"white"
  },
  centro:{
    alignItems:"center",
    padding:30
  }
}