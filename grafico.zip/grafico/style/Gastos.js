export default{
      tamanho:{
      flexDirection: 'row',
      padding:10,
      margin:10,
      backgroundColor: "rgba(174, 85, 228, 0.5)",
      height:85,
      borderRadius:5,
      alignItems:"center",
      gap:15,
      width:"85%"
    }
}