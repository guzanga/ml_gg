export default{
    logo:{
    padding:2,
    fontSize:15,
    color:"white"
  },   
  lado:{
    flexDirection: 'row',
    margin:2,
    alignItems:"center",
    paddingHorizontal:10,
    paddingTop:35,
  },
}