export default{
  cor:{
    color:"white",
    fontSize:15
  },
  drop:{
    backgroundColor:"#AE55E4",
    opacity:0.55,
    borderWidth:0,
  },
  swith:{
    paddingTop:25
  }

}