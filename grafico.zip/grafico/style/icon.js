export default{
      icondecor:{
        fontSize:55,
        color:"white",
    }
}