export default{
  vermei:{
    color:"#FF7272",
    fontSize:15
  },
}