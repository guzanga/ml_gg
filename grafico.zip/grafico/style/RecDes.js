export default{
  lado2:{
    flexDirection: 'row',
    padding:25,
    alignItems:"center",
  },  
  lado3:{
    flexDirection: 'row',
    paddingHorizontal:20,
    alignItems:"center",
    gap:7
  },
  verdi:{
    color:"#67F8BB"
  },
  vermei:{
    color:"#FF7272"
  },
    menos:{
    color:"#FF7272",
    fontSize:55
  },
    maior:{
    color:"#67F8BB",
    fontSize:55
  },
    saldo:{
    color:"white",
    fontSize:15,
  }, }