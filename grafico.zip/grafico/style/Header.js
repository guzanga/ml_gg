export default{
    ml:{
    borderRadius:25,
    backgroundColor:"#42286C",
    width:"100%",
      textAlign:"center",
    justifyContent:" center"
  },
  parte1:{
     alignItems:"center",
     padding:20,
  },
    din:{
    color:"white",
    fontSize:40
  },
    saldo:{
    color:"#C0C0C0",
    fontSize:15,
  }, 
    titulo1:{
    color:"white",
    fontSize:20
  },
}