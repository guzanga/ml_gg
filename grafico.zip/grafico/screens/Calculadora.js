import {View} from "react-native"
import Titulo from "../components/Titulo"
import Linear from "../components/Linear"
import style from "../style/Calc"
import NomCat from "../components/NomeCat"

export default function ValorUltimosGastos(){
  return(
    <View  style={style.container}>
    <Linear>
    <Titulo></Titulo>
    <NomCat></NomCat>
    </Linear>
    </View>
  )
}