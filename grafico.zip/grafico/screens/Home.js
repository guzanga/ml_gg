import { SafeAreaView} from "react-native"
import Linear from "../components/Linear"
import style from "../style/Home"
import Header from "../components/Header"
import Grafico from "../components/Grafico"
import Ultimos_Gastos from "../components/Gastos"
import UltGast from "../components/UltimosGastos"
import Scroll from "../reutilizaveis/Scroll"

export default function Home(){
  return( 
    <SafeAreaView style={style.container}>
    <Scroll>
      <Linear>
      <Header></Header>
      <Grafico></Grafico>
      <UltGast></UltGast>
      <Ultimos_Gastos></Ultimos_Gastos>
      </Linear>
    </Scroll>
    </SafeAreaView>
  )
}