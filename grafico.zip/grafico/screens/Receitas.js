import { SafeAreaView, View, Text, StyleSheet, TextInput, Pressable } from 'react-native';

export default function  ({navigation}) {

function cadastrar() {

  navigation.navigate('Home')
}

  return(
    <View style={style.back}>

        <Text style={style.title}>Receita</Text>

        <View style={style.area}>

          <Text>Nome:</Text>
          <TextInput onChangeText={ (e) => setNome(e)} style={style.inp}></TextInput>

        </View>

        <View style={style.area}>

          <Text>Valor:</Text>
          <TextInput onChangeText={ (e) => setValor(e)} style={style.inp}></TextInput>

        </View>

        <View style={style.area}>

          <Text>Data:</Text>
          <TextInput onChangeText={ (e) => setData(e)} style={style.inp}></TextInput>

        </View>



        <Pressable  style={style.bb} onPress={cadastrar}>
            <Text>Cadastrar</Text>
        </Pressable>
    </View>
  )
}

const style = StyleSheet.create({

  back:{
    backgroundColor:"white",
    flex: 1,
    alignItems:"center",
    justifyContent:"center"
  },

  title:{
    fontSize:30,
    

  },
    bb:{
    padding: 10,
    margin:2,
    borderWidth:1,
    borderColor: 'red',
    borderRadius:4,
  },

  inp:{
    borderRadius:4,
    borderWidth:1,
    width:200,
    height:35,
    borderColor:"green",
  },

  area:{
    margin:10
  }

})