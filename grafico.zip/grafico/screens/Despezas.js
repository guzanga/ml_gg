import React, { useState, useContext} from 'react';
import {StyleSheet, View, Text, Pressable, TextInput} from "react-native"
import Dados from '../context/DadosContext'

export default function Despezas({navigation}){

  const {despesas, setDespesas} = useContext (Dados)
  const [nome, setNome]  = useState('')
  const [valor, setValor] = useState(0)
  const [data, setData] = useState(0)

  function cadastrar() {
    let axlr = [...despesas]
    axlr .push({ 
      nome: nome,
      valor: valor,
      data: data
    })

    setDespesas(axlr)

    navigation.navigate('Home')
}

  return(
     <View style={style.back}>

        <Text style={style.title}>Despesas</Text>

        <View style={style.area}>

          <Text>Nome:</Text>
          <TextInput value={nome} onChangeText={ (e) => setNome(e)} style={style.inp}></TextInput>

        </View>
        
        <View style={style.area}>

          <Text>Valor:</Text>
          <TextInput value={valor} onChangeText={ (e) => setValor(e)} style={style.inp}></TextInput>

        </View>

        <View style={style.area}>

          <Text>Data:</Text>
          <TextInput value={data} onChangeText={ (e) => setData(e)} style={style.inp}></TextInput>

        </View>



        <Pressable style={style.bb} onPress={cadastrar}>
            <Text>Cadastrar</Text>
        </Pressable>
    </View>
  )
}

const style = StyleSheet.create({

  back:{
    backgroundColor:"white",
    flex: 1,
    alignItems:"center",
    justifyContent:"center"
  },

  title:{
    fontSize:30

  },
    bb:{
    padding: 10,
    margin:2,
    borderWidth:2,
    borderColor: 'red',
    borderRadius:4
  },

  inp:{
    borderRadius:4,
    borderWidth:2,
    width:200,
    height:35,
    borderColor:"green",
  },

  area:{
    margin:10
  }

})